import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product-item',
  standalone: true,
  imports: [],
  templateUrl: './product-item.component.html',
  styleUrl: './product-item.component.css'
})
export class ProductItemComponent {
  @Input() name: string ='';
  @Input() price: number = 0;

  @Output() addToCart: EventEmitter<void> = new EventEmitter<void>();

  onAddToCart(): void {
    this.addToCart.emit();
  }
}
