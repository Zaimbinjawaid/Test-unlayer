<template>
  <div>
    <h1>{{ msg }}</h1>
    <ul>
      Add an item to the List:
      <input type="text" v-model="newTodoText" @keyup.enter="addTodo" />
      <ul>
        <div
          v-for="(todo, index) in todos"
          :key="todo.id"
          class="item-class" 
          :class="{ completed: todo.completed }"
        >
          <span @click="toggleCompletion(todo)"
            >{{ index + 1 }} - {{ todo.text }}</span
          >
          <button @click="deleteTodo(index)">Delete</button>
      </div>
      </ul>
    </ul>
  </div>
</template>

<script>
export default {
  name: "ToDoList",
  props: {
    msg: String,
  },
  data() {
    return {
      todos: [],
      newTodoText: "",
    };
  },
  methods: {
    addTodo() {
      if (this.newTodoText.trim() === "") return;
      this.todos.push({
        id: Date.now(),
        text: this.newTodoText,
        completed: false,
      });
      this.newTodoText = "";
    },
    deleteTodo(index) {
      this.todos.splice(index, 1);
    },
    toggleCompletion(todo) {
      todo.completed = !todo.completed;
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.completed {
  text-decoration: line-through;
}
.item-class {
  padding: 5px;
  cursor: pointer;
}
</style>
