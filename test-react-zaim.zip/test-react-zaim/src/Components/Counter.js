import React from 'react';
function Counter({ count, onIncrement, onDecrement, onReset }) {
  return (
    <main className="App">
      <p>Count: {count}</p>
      <button onClick={onIncrement}>Increment</button>
      <button onClick={onDecrement}>Decrement</button>
      <button onClick={onReset}>Reset</button>
    </main>
  );
}
export default Counter;