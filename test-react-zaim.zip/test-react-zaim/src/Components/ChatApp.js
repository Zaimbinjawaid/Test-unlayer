import React, { useEffect, useRef, useState } from 'react';
import { v4 as generateUUID } from 'uuid';
const ChatApp = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [notificationPermission, setNotificationPermission] = useState(false);

  const isPageHidden = useRef(false);

  const handlePageVisibilityChange = () => {
    isPageHidden.current = document.hidden;
    console.log('Page visibility changed:', isPageHidden.current);
  };


  useEffect(() => {
    if ('Notification' in window) {
      Notification.requestPermission().then((permission) => {
        console.log('Notification permission:', permission);
        setNotificationPermission(permission === 'granted');
      });
      document.addEventListener('visibilitychange', handlePageVisibilityChange);

      return () => {
        document.removeEventListener('visibilitychange', handlePageVisibilityChange);
      };
    }
  }, []);


  useEffect(() => {
  if (notificationPermission && isPageHidden.current) {
    console.log('Creating notification...');
    const notificationId = generateUUID();
    new Notification('New Message', {
      body: 'You have a new message!',
      tag: notificationId,
    });
    console.log('Notification created.');
  }
}, [messages, notificationPermission]);


  const handleNewMessage = () => {
    setMessages((prevMessages) => [...prevMessages, newMessage]);
    setNewMessage('');
  };

  

  return (
    <div>
      <div>
        {messages.map((message, index) => (
          <div key={index}>{message}</div>
        ))}
      </div>

      <input
        type="text"
        value={newMessage}
        onChange={(e) => setNewMessage(e.target.value)}
      />
      <button onClick={handleNewMessage}>Send</button>
    </div>
  );
};

export default ChatApp;