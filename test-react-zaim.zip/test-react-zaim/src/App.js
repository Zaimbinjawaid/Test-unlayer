import React, {useState} from 'react';
import style from './App.css';
import Counter from './Components/Counter';
import ChatApp from './Components/ChatApp';

function App() {
  const [count, setCount] = useState(0);

  const handleIncrement = () => {
    setCount(count + 1);
  };

  const handleDecrement = () => {
    setCount(count - 1);
  };

  const handleReset = () => {
    setCount(0);
  };

  return (
    <>
    <Counter
      count={count}
      onIncrement={handleIncrement}
      onDecrement={handleDecrement}
      onReset={handleReset}
    />

    <ChatApp/>
    </>
  );
}

export default App;
